-- Instructions
Use Arrown Left and Right to move.
Shoot other aircraft with Spacebar.